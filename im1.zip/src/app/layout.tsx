import "./globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { AppProvider } from "@/context/app-context"
import { Toaster } from "sonner"
import { HardwareAcceleration } from "./hardware-acceleration"
import Link from "next/link";
import { Calendar, Home } from "lucide-react";

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <style>{`
          /* Critical CSS for fast transitions */
          * {
            transition-duration: 80ms;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
          }

          .card, [role="dialog"], [role="tabpanel"] {
            transition: transform 150ms, opacity 150ms;
          }
        `}</style>
      </head>
      <body className={`${inter.className} antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <AppProvider>
            <HardwareAcceleration />
            <Toaster
              position="top-right"
              toastOptions={{
                duration: 2000
              }}
            />
            <div className="flex min-h-screen">
              <aside className="hidden md:block w-64 border-r shrink-0 bg-background/95">
                <div className="sticky top-0 h-screen overflow-y-auto p-4">
                  <div className="flex items-center gap-2 mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M2 2v20h20" />
                      <path d="M6 16 10 7l4 5 4-11" />
                    </svg>
                    <h1 className="text-lg font-semibold">Stock Industry Mapper</h1>
                  </div>

                  <nav className="space-y-1">
                    <Link href="/" className="flex items-center gap-2 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                      <Home className="h-4 w-4" />
                      <span>Dashboard</span>
                    </Link>
                    <Link href="/results-calendar-export" className="flex items-center gap-2 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                      <Calendar className="h-4 w-4" />
                      <span>Results Calendar Export</span>
                    </Link>
                  </nav>
                </div>
              </aside>

              <main className="flex-1 flex flex-col">
                {children}
              </main>
            </div>
          </AppProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
